export class RatingValue {
  ratingAvg: number;
  ratingCnt: number;
}
